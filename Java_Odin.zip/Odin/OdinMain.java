
import frame.*;
import java.io.IOException;

public class OdinMain {    

    public static void main(String[] args) throws IOException {
        OdinUI frameUI = new OdinUI();
        
        frameUI.createOdinUI();
        
    } // main  
} // class